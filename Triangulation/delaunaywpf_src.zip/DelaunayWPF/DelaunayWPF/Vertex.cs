﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MIConvexHull;
using System.Windows.Media.Media3D;

namespace DelaunayWPF
{
    /// <summary>
    /// Represents a point in 3D space.
    /// </summary>
    class Vertex : IVertexConvHull
    {
        public double[] coordinates { get; set; }
        public Point3D Position { get { return new Point3D(coordinates[0], coordinates[1], coordinates[2]); } }

        public Vertex(double x, double y, double z)
        {
            coordinates = new double[] { x, y, z };
        }
    }
}
