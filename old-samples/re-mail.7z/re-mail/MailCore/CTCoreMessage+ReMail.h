//
//  CTCoreMessage+ReMail.h
//
//  Created by Stefano Barbato on 25/06/09.
//  Copyright 2010 Google Inc.
//  
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//  
//   http://www.apache.org/licenses/LICENSE-2.0
//  
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//
//  Additions to CTCoreMessage for fields we need to read out (mostly time-related).

#import "CTCoreMessage.h" 

@interface CTCoreMessage ( CTCoreMessageReMail ) 

// returns the timezone of the sender of the message (got from the Date field timezone attribute)
- (NSTimeZone*)senderTimeZone;

// returns the date as given in the Date mail field (no timezone is applied)
- (NSDate *)senderDate; 

// returns the date in the Date field converted to GMT
- (NSDate *)sentDateGMT; 

// returns the date in the Date field converted to the local timezone
// the local timezone is the one set in the device running this code
- (NSDate *)sentDateLocalTimeZone; 

// returns the message-id field of the message
- (NSString*)messageId;

@end 

