package com.google.android.mms;

import android.net.Uri;

public class MMSPart {
    public String Name = "";
    public String MimeType = "";
    public byte[] Data;
    public Uri Path;
}